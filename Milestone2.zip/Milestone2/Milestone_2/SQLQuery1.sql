﻿INSERT INTO [dbo].[Register] (FIRSTNAME, LASTNAME, SEX, AGE, STATE, EMAIL, USERNAME, PASSWORD) VALUES ('Firstname', 'Lastname', 'Male', '35', 'AZ', 'Email', 'Username', 'Password');

SELECT * FROM [dbo].[Register]