﻿using Microsoft.AspNetCore.Mvc;
using CST_350_Milestone.Services;
using CST_350_Milestone.Models;

namespace CST_350_Milestone.Controllers
{
    public class LoginController : Controller
    {
        private readonly SecurityService _securityService;

        public LoginController(SecurityService securityService)
        {
            _securityService = securityService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ProcessLogin(RegisterModel user)
        {
            if (_securityService.IsValid(user))
                //return View("LoginSuccess", user);
                return RedirectToAction("Index", "Minesweeper");

            else
                return View("LoginFailure", user);
        }
    }
}
