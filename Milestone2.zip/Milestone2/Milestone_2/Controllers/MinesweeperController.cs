﻿using CST_350_Milestone.Models;
using CST_350_Milestone.Services;
using Microsoft.AspNetCore.Mvc;

namespace CST_350_Milestone.Controllers
{
    public class MinesweeperController : Controller
    {
        private readonly MinesweeperService _minesweeperService;

        public MinesweeperController(MinesweeperService minesweeperService)
        {
            _minesweeperService = minesweeperService;
        }

        public IActionResult Index()
        {
            // This creates a new Minesweeper board, you can adjust width, height, and mineCount.
            var model = _minesweeperService.CreateBoard(10, 10, 20);
            return View(model);
        }

        [HttpPost]
        public IActionResult RevealCell(int x, int y)
        {
            // Get current board from Session or Database (you will need to implement this)
            var model = GetCurrentBoard();

            _minesweeperService.RevealCell(model, x, y);

            // Save updated board to Session or Database (you will need to implement this)
            SaveCurrentBoard(model);

            return Json(new
            {
                cellData = new
                {
                    isRevealed = model.Cells[x, y].IsRevealed,
                    isMine = model.Cells[x, y].IsMine,
                    neighboringMines = model.Cells[x, y].NeighboringMines
                }
            });
        }

        private MinesweeperModel GetCurrentBoard()
        {
            // Logic to retrieve the current board from Session or Database.
            // For this example, I'll just return a new board.
            return _minesweeperService.CreateBoard(10, 10, 20);
        }

        private void SaveCurrentBoard(MinesweeperModel model)
        {
            // Logic to save the updated board to Session or Database.
        }
    }
}
